# Trendgram Frontend

Instructions: set REACT_APP_API_URL in Vercel environment variables then deploy.