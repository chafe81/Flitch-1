import React, { useState } from "react"

export default function VideoCard({ item, isFavorite, onToggleFavorite, darkMode }) {
  const [copied, setCopied] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [downloadId, setDownloadId] = useState(null)

  const handleCopy = () => {
    navigator.clipboard.writeText(item.src || item.url || item.permalink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleDownload = () => {
    const base = process.env.REACT_APP_API_URL || "http://localhost:4000"
    const url = item.src || item.url || item.permalink || ""
    const id = `${item.externalId}_${Date.now()}`
    setDownloadId(id)
    setDownloading(true)
    setProgress(0)

    const evtSource = new EventSource(`${base}/api/download-progress?url=${encodeURIComponent(url)}&id=${id}`)

    evtSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        if (data.progress) setProgress(parseFloat(data.progress))
        if (data.file) {
          setProgress(100)
          setDownloading(false)
          evtSource.close()
          // trigger file download
          const a = document.createElement("a")
          a.href = `${base}${data.file}`
          a.download = `${item.title ? item.title.replace(/\s+/g, "_") : "video"}.mp4`
          document.body.appendChild(a)
          a.click()
          a.remove()
        }
        if (data.error) {
          alert("Download failed or canceled")
          setDownloading(false)
          evtSource.close()
        }
      } catch (e) {
        console.error("SSE parse error", e)
      }
    }
  }

  const handleCancel = async () => {
    if (!downloadId) return
    const base = process.env.REACT_APP_API_URL || "http://localhost:4000"
    await fetch(`${base}/api/cancel-download?id=${downloadId}`)
    setDownloading(false)
    setProgress(0)
  }

  const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(item.title || "")}%20${encodeURIComponent(item.src || item.url || "")}`
  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(item.title || "")}&url=${encodeURIComponent(item.src || item.url || "")}`

  return (
    <div className={`w-full max-w-md rounded-2xl shadow-md p-4 mb-4 ${darkMode ? "bg-gray-800 text-white" : "bg-white text-black"}`}>
      <div className="flex justify-between items-start">
        <h2 className="text-lg font-semibold flex-1 pr-2">{item.title}</h2>
        <button onClick={() => onToggleFavorite && onToggleFavorite(item)} className={`text-xl ${isFavorite ? "text-yellow-500" : "text-gray-400"}`}>
          ⭐
        </button>
      </div>

      <p className="text-sm opacity-80">By {item.username}</p>
      <p className="text-xs opacity-70">Views: {item.views} | Likes: {item.likes}</p>

      <div className="flex flex-wrap gap-2 mt-3">
        <button onClick={handleCopy} className={`px-3 py-1 rounded-lg text-sm ${darkMode ? "bg-gray-700 hover:bg-gray-600" : "bg-gray-200 hover:bg-gray-300"}`}>
          {copied ? "✅ Copied!" : "📋 Copy Link"}
        </button>

        <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="px-3 py-1 rounded-lg text-sm bg-green-500 text-white hover:bg-green-600">
          WhatsApp
        </a>

        <a href={twitterUrl} target="_blank" rel="noopener noreferrer" className="px-3 py-1 rounded-lg text-sm bg-blue-500 text-white hover:bg-blue-600">
          Twitter
        </a>

        {!downloading ? (
          <button onClick={handleDownload} className="px-3 py-1 rounded-lg text-sm bg-red-500 text-white hover:bg-red-600">
            ⬇️ Download
          </button>
        ) : (
          <div className="flex gap-2 items-center">
            <span className="text-sm">⬇️ {progress}%</span>
            <button onClick={handleCancel} className="px-3 py-1 rounded-lg text-sm bg-gray-500 text-white hover:bg-gray-600">✖ Cancel</button>
          </div>
        )}
      </div>

      <a href={item.src || item.url || item.permalink} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-blue-400 hover:underline">Watch →</a>
    </div>
  )
}