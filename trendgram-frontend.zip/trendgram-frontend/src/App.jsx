import React, { useEffect, useState } from "react"
import VideoCard from "./VideoCard"

export default function App() {
  const [darkMode, setDarkMode] = useState(false)
  const [feed, setFeed] = useState([])

  useEffect(() => {
    async function load() {
      try {
        const base = process.env.REACT_APP_API_URL || "http://localhost:4000"
        const res = await fetch(`${base}/api/feed?platform=all&limit=6`)
        const json = await res.json()
        if (json.ok) setFeed(json.data)
      } catch (err) {
        console.error(err)
      }
    }
    load()
  }, [])

  return (
    <div className={darkMode ? "dark" : ""}>
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-4">
        <header className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">🔥 Trendgram</h1>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="px-3 py-1 rounded bg-gray-300 dark:bg-gray-700 dark:text-white"
          >
            {darkMode ? "☀️ Light" : "🌙 Dark"}
          </button>
        </header>

        {feed.map((item) => (
          <VideoCard
            key={item.externalId}
            item={item}
            darkMode={darkMode}
            isFavorite={false}
            onToggleFavorite={() => {}}
          />
        ))}
      </div>
    </div>
  )
}