# Trendgram Backend

Instructions: build with Docker and deploy to Render.