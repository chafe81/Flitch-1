const express = require("express")
const cors = require("cors")
const { spawn } = require("child_process")
const path = require("path")

const app = express()
app.use(cors())

const activeDownloads = {}

app.get("/api/download-progress", (req, res) => {
  const { url, id } = req.query
  if (!url || !id) return res.status(400).json({ ok: false, error: "Missing URL or ID" })

  res.setHeader("Content-Type", "text/event-stream")
  res.setHeader("Cache-Control", "no-cache")
  res.setHeader("Connection", "keep-alive")

  const safeFilename = `trendgram_${Date.now()}.mp4`
  const filePath = path.join(__dirname, safeFilename)

  const ytdlp = spawn("yt-dlp", ["-f", "best", "--newline", "-o", filePath, url])
  activeDownloads[id] = ytdlp

  ytdlp.stdout.on("data", (data) => {
    const line = data.toString()
    const match = line.match(/(\\d+\\.\\d+)%/)
    if (match) {
      res.write(`data: ${JSON.stringify({ progress: match[1] })}\\n\\n`)
    }
  })

  ytdlp.on("close", (code) => {
    delete activeDownloads[id]
    if (code === 0) {
      res.write(`data: ${JSON.stringify({ progress: "100", file: `/api/file/${safeFilename}` })}\\n\\n`)
    } else {
      res.write(`data: ${JSON.stringify({ error: "Download canceled or failed" })}\\n\\n`)
    }
    res.end()
  })
})

app.get("/api/cancel-download", (req, res) => {
  const { id } = req.query
  if (!id || !activeDownloads[id]) {
    return res.json({ ok: false, error: "No active download" })
  }
  activeDownloads[id].kill("SIGINT")
  delete activeDownloads[id]
  res.json({ ok: true, message: "Download canceled" })
})

app.get("/api/file/:filename", (req, res) => {
  const filePath = path.join(__dirname, req.params.filename)
  res.download(filePath)
})

const PORT = process.env.PORT || 4000
app.listen(PORT, () => {
  console.log(`🚀 Trendgram backend running on port ${PORT}`)
})
